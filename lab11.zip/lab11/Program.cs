﻿Laptop dell=new(1,"dell(11)","linux");
dell.DisplayInfo();
dell.Start();