
public abstract class Device
{
    public int Id { get; set; }
    public string Name { get; set; }

public Device(int id, string name)
{
     this.Id = id;
    this.Name = name;
}
 public virtual void DisplayInfo()
    {
    Console.WriteLine($"ID: {Id}");
   Console.WriteLine($"Name: {Name}");
    }
public abstract void Start();
}