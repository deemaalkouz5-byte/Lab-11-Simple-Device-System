public  class  Laptop : Device{
    string OperatingSystem { get; set; }
    public Laptop( int Id , string Name, string OperatingSystem) : base(Id, Name){
        this.OperatingSystem = OperatingSystem;
    }
    public override void Start()
    {
        Console.WriteLine($"The laptop is starting.");
}
    public override void DisplayInfo()
    {
        base.DisplayInfo();
        Console.WriteLine($"OS: {OperatingSystem}");
    }
}